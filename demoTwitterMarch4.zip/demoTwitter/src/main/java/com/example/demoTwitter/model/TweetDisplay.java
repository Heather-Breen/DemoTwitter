package com.example.demoTwitter.model;public class TweetDisplay {
}
