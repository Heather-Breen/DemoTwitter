package com.example.demoTwitter.repo;public interface TagRepository {
}
