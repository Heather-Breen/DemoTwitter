package com.example.demoTwitter.authentication;public class ThymeleafConfiguration {
}
