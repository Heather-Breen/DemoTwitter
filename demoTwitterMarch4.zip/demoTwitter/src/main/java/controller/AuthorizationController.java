package controller;

public class AuthorizationController {
}
